STYLE = """
QMainWindow, QWidget { font-size: 13px; }
QDockWidget::title { padding: 4px; background: #eef0f5; }
QGroupBox { font-weight: 600; border: 1px solid #d5d9e2; border-radius: 6px; margin-top: 10px; padding: 8px 6px 6px 6px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: #2b3a67; }
QPushButton { padding: 5px 8px; border: 1px solid #c3c9d6; border-radius: 5px; background: #f6f7fb; }
QPushButton:hover { background: #e8ecf8; }
QPushButton:checked { background: #3b5bdb; color: white; border-color: #3b5bdb; }
QPushButton#primary { background: #3b5bdb; color: white; border-color: #3b5bdb; font-weight: 600; }
QPushButton#primary:hover { background: #2f4ac0; }
QStatusBar QLabel { padding: 0 10px; }
"""
